sap.ui.define([
	"ca/toyota/demoreservation/demoreservation/test/unit/controller/App.controller"
], function () {
	"use strict";
});